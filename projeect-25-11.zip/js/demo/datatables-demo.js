// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTableJudge-1').DataTable();
});
$(document).ready(function() {
  $('#dataTableJudge-2').DataTable();
});
$(document).ready(function() {
  $('#dataTable').DataTable();
});